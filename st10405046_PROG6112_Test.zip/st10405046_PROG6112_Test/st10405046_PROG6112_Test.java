import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

      //Output of the entire page
      
      System.out.println("--------------------------------------------");
      System.out.println("GAMING CONSOLE REPORT");
      System.out.println("--------------------------------------------");
      System.out.println("                   PS5     XBOX     SWITCH");
      System.out.println("CAPE TOWN          1000    2000     3000");
      System.out.println("PORT ELIZABETH     2000    3000     4000");
      System.out.println("PRETORIA           1500    1100     1200");
      
      System.out.println("--------------------------------------------");
      System.out.println("CONSOLE SALES TOTALS FOR EACH CITY");
      System.out.println("--------------------------------------------");

      System.out.println("CAPE TOWN         6000");
      System.out.println("PORT ELIZABETH    9000");
      System.out.println("PRETORIA          3800");
      

      System.out.string(getConsoleType)


      }
}